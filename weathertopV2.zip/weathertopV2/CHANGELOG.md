# Playlist Changelog

## version 0.1.0

- initial version ported from glitch-template
- introduce weather station store model for simple weather stations
- allow weather stations to be added to this model
- list all weather stations in the model
