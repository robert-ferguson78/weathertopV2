# weathertopV2
This is an applictaion re-write from the Wetahertop java assignmnet to re-code in Express.js, Handlebars hosted on Glitch enviornment.
